# chromium extension for taguette functionality

currently supports:
- quick add new tag to highlight with "`"

it's built for taguette 1.1 but should run on newer versions
change the domain in manifest if applicable

to-do:
- [ ] change extension icon when active
- [ ] customizeable hotkey
- [ ] see tags on hover
- [ ] search tags
